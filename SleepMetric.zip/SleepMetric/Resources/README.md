# Sleep Metric

A personal energy tracking app for iOS built with SwiftUI + SwiftData.

## Files
| File | Description |
|------|-------------|
| SleepMetricApp.swift | App entry point, onboarding gate |
| Models.swift | SwiftData models (SleepEntry, CaffeineEntry, MoodEntry) |
| Services.swift | EnergyScoreService, SleepAnalysisService, InsightsService, NotificationService |
| DesignSystem.swift | Colors, reusable components (EnergyRing, StatCard, etc.) |
| ContentView.swift | TabBar container + DashboardView |
| OnboardingView.swift | 4-page onboarding flow |
| LogSleepSheet.swift | Log sleep sheet |
| LogCaffeineSheet.swift | Log caffeine sheet |
| LogMoodSheet.swift | Log mood sheet |
| InsightsView.swift | AI-style pattern insights |
| HistoryView.swift | Sleep/caffeine/mood history |
| SettingsView.swift | Notifications, data management |
| Info.plist | App name, permissions |

